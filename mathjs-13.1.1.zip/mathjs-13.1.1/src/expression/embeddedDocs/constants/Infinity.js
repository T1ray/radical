export const InfinityDocs = {
  name: 'Infinity',
  category: 'Constants',
  syntax: [
    'Infinity'
  ],
  description: 'Infinity, a number which is larger than the maximum number that can be handled by a floating point number.',
  examples: [
    'Infinity',
    '1 / 0'
  ],
  seealso: []
}
